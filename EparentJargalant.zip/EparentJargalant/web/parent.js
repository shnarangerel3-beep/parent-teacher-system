document.getElementById('btnSearch').addEventListener('click', async () => {
  const reg = document.getElementById('reg').value.trim();
  if (!reg) return alert('Регистрийн дугаар оруулна уу');
  try {
    const student = await API.get('/api/students/' + encodeURIComponent(reg));
    document.getElementById('studentCard').style.display = 'block';
    document.getElementById('attendanceCard').style.display = 'block';
    document.getElementById('notesCard').style.display = 'block';
    document.getElementById('hwCard').style.display = 'block';

    document.getElementById('studentName').textContent = student.last_name + ' ' + student.first_name;
    document.getElementById('studentGrade').textContent = student.grade || '-';
    document.getElementById('studentReg').textContent = student.register_id;

    const [att, notes, hw] = await Promise.all([
      API.get('/api/students/' + student.id + '/attendance'),
      API.get('/api/students/' + student.id + '/notes'),
      API.get('/api/students/' + student.id + '/homework'),
    ]);

    const abody = document.getElementById('attendanceBody');
    abody.innerHTML = '';
    att.forEach(row => {
      const tr = document.createElement('tr');
      const badgeClass = row.status;
      tr.innerHTML = `<td>${row.date}</td><td><span class="badge ${badgeClass}">${row.status}</span></td><td>${row.minutes_late || 0}</td>`;
      abody.appendChild(tr);
    });

    const nbody = document.getElementById('notesBody');
    nbody.innerHTML = '';
    notes.forEach(row => {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${row.date}</td><td>${row.category || '-'}</td><td>${row.remark}</td>`;
      nbody.appendChild(tr);
    });

    const hbody = document.getElementById('hwBody');
    hbody.innerHTML = '';
    hw.forEach(row => {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${row.date}</td><td>${row.title}</td><td>${row.status}</td><td>${row.remark || ''}</td>`;
      hbody.appendChild(tr);
    });
  } catch (e) {
    alert('Олдсонгүй эсвэл алдаа: ' + e);
  }
});
