// Simple API helper
const API = {
  base: '',
  token: null,
  setToken(t){ this.token = t },
  async get(path){
    const res = await fetch(this.base + path, { headers: this.token ? { 'Authorization': 'Bearer ' + this.token } : {} });
    if(!res.ok) throw new Error(await res.text());
    return res.json();
  },
  async post(path, data){
    const res = await fetch(this.base + path, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(this.token ? { 'Authorization': 'Bearer ' + this.token } : {})
      },
      body: JSON.stringify(data)
    });
    if(!res.ok) throw new Error(await res.text());
    return res.json();
  }
};
