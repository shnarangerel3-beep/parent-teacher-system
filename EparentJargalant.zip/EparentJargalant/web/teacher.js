const els = (id) => document.getElementById(id);

async function login(){
  try {
    const data = await API.post('/api/login', {
      username: els('username').value.trim(),
      password: els('password').value.trim()
    });
    API.setToken(data.token);
    els('loginCard').style.display = 'none';
    els('panel').style.display = 'block';
    await refreshStudents();
  } catch (e) {
    alert('Нэвтрэх амжилтгүй: ' + e);
  }
}

async function refreshStudents(){
  const rows = await API.get('/api/students');
  const body = els('studentsBody');
  body.innerHTML = '';
  rows.forEach(r => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${r.id}</td><td>${r.register_id}</td><td>${r.last_name} ${r.first_name}</td><td>${r.grade || ''}</td>`;
    body.appendChild(tr);
  });
}

async function addStudent(){
  try {
    await API.post('/api/students', {
      register_id: els('s_reg').value.trim(),
      first_name: els('s_fn').value.trim(),
      last_name: els('s_ln').value.trim(),
      grade: els('s_grade').value.trim(),
      dob: els('s_dob').value.trim()
    });
    await refreshStudents();
  } catch (e) {
    alert('Алдаа: ' + e);
  }
}

async function addAttendance(){
  try {
    await API.post('/api/attendance', {
      student_id: Number(els('a_student_id').value),
      date: els('a_date').value.trim(),
      status: els('a_status').value,
      minutes_late: Number(els('a_minutes').value || 0)
    });
    alert('Ирц хадгалагдлаа');
  } catch (e) {
    alert('Алдаа: ' + e);
  }
}

async function addNote(){
  try {
    await API.post('/api/notes', {
      student_id: Number(els('n_student_id').value),
      date: els('n_date').value.trim(),
      category: els('n_category').value.trim(),
      remark: els('n_remark').value.trim()
    });
    alert('Тэмдэглэл хадгалагдлаа');
  } catch (e) {
    alert('Алдаа: ' + e);
  }
}

async function addHw(){
  try {
    await API.post('/api/homework', {
      student_id: Number(els('h_student_id').value),
      date: els('h_date').value.trim(),
      title: els('h_title').value.trim(),
      status: els('h_status').value,
      remark: els('h_remark').value.trim()
    });
    alert('Даалгавар хадгалагдлаа');
  } catch (e) {
    alert('Алдаа: ' + e);
  }
}

document.getElementById('btnLogin').addEventListener('click', login);
document.getElementById('btnRefresh').addEventListener('click', refreshStudents);
document.getElementById('btnAddStudent').addEventListener('click', addStudent);
document.getElementById('btnAddAtt').addEventListener('click', addAttendance);
document.getElementById('btnAddNote').addEventListener('click', addNote);
document.getElementById('btnAddHw').addEventListener('click', addHw);
