-- Students
CREATE TABLE IF NOT EXISTS students (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  register_id TEXT UNIQUE NOT NULL,   -- Регистрийн дугаар
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  grade TEXT,
  dob TEXT                            -- төрсөн огноо (YYYY-MM-DD), demo-д хэрэглэнэ
);

-- Attendance
CREATE TABLE IF NOT EXISTS attendance (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL,
  date TEXT NOT NULL,                 -- YYYY-MM-DD
  status TEXT NOT NULL,               -- present | absent | tardy
  minutes_late INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(student_id) REFERENCES students(id)
);

-- Notes (teacher remarks)
CREATE TABLE IF NOT EXISTS notes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL,
  date TEXT NOT NULL,
  category TEXT,                      -- attention_low, sleeping, behavior, etc.
  remark TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(student_id) REFERENCES students(id)
);

-- Homework
CREATE TABLE IF NOT EXISTS homework (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL,
  date TEXT NOT NULL,
  title TEXT NOT NULL,
  status TEXT NOT NULL,               -- assigned | submitted | missing
  remark TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(student_id) REFERENCES students(id)
);

-- Seed example students
INSERT OR IGNORE INTO students (register_id, first_name, last_name, grade, dob)
VALUES
 ('AB12345678', 'Anar', 'Bat', '5A', '2014-03-12'),
 ('CD87654321', 'Sarnai', 'Erdene', '6B', '2013-09-05');

-- Seed some example records
INSERT INTO attendance (student_id, date, status, minutes_late)
SELECT id, '2025-09-01', 'present', 0 FROM students WHERE register_id='AB12345678';

INSERT INTO notes (student_id, date, category, remark)
SELECT id, '2025-09-01', 'attention_low', 'Анхаарал сул байсан' FROM students WHERE register_id='AB12345678';

INSERT INTO homework (student_id, date, title, status, remark)
SELECT id, '2025-09-01', 'Math p.12 #1-5', 'assigned', '' FROM students WHERE register_id='AB12345678';
