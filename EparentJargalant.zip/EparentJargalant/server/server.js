require('dotenv').config();
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const path = require('path');

const db = require('./db');
const app = express();

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';

app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// Serve static frontend
app.use('/', express.static(path.join(__dirname, '..', 'web')));

// Simple in-memory user for demo, fallback to env (hashed on boot)
const adminUser = {
  username: process.env.ADMIN_USERNAME || 'teacher1',
  passwordHash: bcrypt.hashSync(process.env.ADMIN_PASSWORD || 'teacher123', 10)
};

function authMiddleware(req, res, next) {
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'No token' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

// --- Auth ---
app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'Missing credentials' });
  if (username === adminUser.username && bcrypt.compareSync(password, adminUser.passwordHash)) {
    const token = jwt.sign({ role: 'teacher', username }, JWT_SECRET, { expiresIn: '8h' });
    return res.json({ token });
  }
  return res.status(401).json({ error: 'Invalid credentials' });
});

// --- Students ---
app.get('/api/students/:registerId', (req, res) => {
  const { registerId } = req.params;
  const stmt = db.prepare('SELECT * FROM students WHERE register_id = ?');
  const student = stmt.get(registerId);
  if (!student) return res.status(404).json({ error: 'Student not found' });
  res.json(student);
});

// --- Attendance ---
app.get('/api/students/:id/attendance', (req, res) => {
  const { id } = req.params;
  const stmt = db.prepare('SELECT * FROM attendance WHERE student_id = ? ORDER BY date DESC, id DESC');
  const rows = stmt.all(id);
  res.json(rows);
});

app.post('/api/attendance', authMiddleware, (req, res) => {
  const { student_id, date, status, minutes_late = 0 } = req.body || {};
  if (!student_id || !date || !status) return res.status(400).json({ error: 'Missing fields' });
  const insert = db.prepare('INSERT INTO attendance (student_id, date, status, minutes_late) VALUES (?, ?, ?, ?)');
  const info = insert.run(student_id, date, status, minutes_late);
  res.json({ id: info.lastInsertRowid });
});

// --- Notes ---
app.get('/api/students/:id/notes', (req, res) => {
  const { id } = req.params;
  const stmt = db.prepare('SELECT * FROM notes WHERE student_id = ? ORDER BY date DESC, id DESC');
  const rows = stmt.all(id);
  res.json(rows);
});

app.post('/api/notes', authMiddleware, (req, res) => {
  const { student_id, date, category, remark } = req.body || {};
  if (!student_id || !date || !remark) return res.status(400).json({ error: 'Missing fields' });
  const insert = db.prepare('INSERT INTO notes (student_id, date, category, remark) VALUES (?, ?, ?, ?)');
  const info = insert.run(student_id, date, category || null, remark);
  res.json({ id: info.lastInsertRowid });
});

// --- Homework ---
app.get('/api/students/:id/homework', (req, res) => {
  const { id } = req.params;
  const stmt = db.prepare('SELECT * FROM homework WHERE student_id = ? ORDER BY date DESC, id DESC');
  const rows = stmt.all(id);
  res.json(rows);
});

app.post('/api/homework', authMiddleware, (req, res) => {
  const { student_id, date, title, status, remark } = req.body || {};
  if (!student_id || !date || !title || !status) return res.status(400).json({ error: 'Missing fields' });
  const insert = db.prepare('INSERT INTO homework (student_id, date, title, status, remark) VALUES (?, ?, ?, ?, ?)');
  const info = insert.run(student_id, date, title, status, remark || null);
  res.json({ id: info.lastInsertRowid });
});

// --- Utility: list students (teacher) ---
app.get('/api/students', authMiddleware, (req, res) => {
  const rows = db.prepare('SELECT * FROM students ORDER BY last_name, first_name').all();
  res.json(rows);
});

// --- Utility: add student (teacher) ---
app.post('/api/students', authMiddleware, (req, res) => {
  const { register_id, first_name, last_name, grade, dob } = req.body || {};
  if (!register_id || !first_name || !last_name) return res.status(400).json({ error: 'Missing fields' });
  const insert = db.prepare('INSERT INTO students (register_id, first_name, last_name, grade, dob) VALUES (?, ?, ?, ?, ?)');
  try {
    const info = insert.run(register_id, first_name, last_name, grade || null, dob || null);
    res.json({ id: info.lastInsertRowid });
  } catch (e) {
    res.status(400).json({ error: 'Duplicate register_id?' });
  }
});

app.listen(PORT, () => {
  console.log(`EparentJargalant server running at http://localhost:${PORT}`);
});
